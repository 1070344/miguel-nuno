#ifndef MapaDigital_
#define MapaDigital_

#include <iostream>

using namespace std;

#include "graphStlPath.h"
#include "Locais.h"
#include "ViasLigacao.h"

template<class TV,class TE>
class MapaDigital
{
	private:
		graphStlPath <Locais, ViasLigacao> mapa; 

	public:
		MapaDigital();
		MapaDigital(const MapaDigital &map);
};


#endif
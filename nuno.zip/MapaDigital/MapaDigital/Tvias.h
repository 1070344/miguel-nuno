#ifndef Tvias_
#define Tvias_

#include <iostream>

using namespace std;

#include "graphStl.h"

class Tvias
{
	private:


	public:
		bool addGraphEdge(const TE& eContent, const TV& vOrigin, const TV& vDestination);
};


#endif